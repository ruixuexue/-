/*
 * WIFI.c
 *
 * created: 2024/6/28
 *  author: 
 */

#include "WIFI.h"
#include <String.h>
#include "../hdc2080/hdc2080.h"




void UART4_Config_Init(void)
{
    unsigned int BaudRate = 115200;
    ls1x_uart_init(devUART4,(void *)BaudRate);
    ls1x_uart_open(devUART4,NULL);
}

void UART3_Config_Init(void)
{
    unsigned int BaudRate = 9600;
    ls1x_uart_init(devUART3,(void *)BaudRate);
    ls1x_uart_open(devUART3,NULL);
}

int count = 0;
char WIFI_buf[1024];            //��������
char Time_arr[300];             //���ʱ��
char Input_arr[300];            //������


void WIFI_Config(int time,char *cmd,char *response)
{
    memset(WIFI_buf,0,1024);
    count = 0;
    count = ls1x_uart_read(devUART4,WIFI_buf,1024,NULL);

    ls1x_uart_write(devUART4,cmd,strlen(cmd),NULL);
    //ls1x_uart_write(devUART3, wrbuf, strlen(wrbuf), NULL);
    while(time--)
    {
        sprintf(Time_arr,"%d\t",time);
        delay_ms(100);
        ls1x_uart_write(devUART3,Time_arr,strlen(Time_arr),NULL);
       // if(strstr(WIFI_buf,response))   break;
    }
    if(time>0)
    {
        sprintf(Input_arr,"�ɹ�\r\n");
        ls1x_uart_write(devUART3,Time_arr,strlen(Time_arr),NULL);
    }
    else
    {
        sprintf(Input_arr,"ʧ��\r\n");
        ls1x_uart_write(devUART3,Time_arr,strlen(Time_arr),NULL);
    }
}


void WIFI_Send(char *cmd)
{
    ls1x_uart_write(devUART4,cmd,strlen(cmd),NULL);
    printf("���͵���� %s", cmd);
    delay_ms(500);

}



void WIFI_pro(void)
{
    WIFI_Send("AT+CWMODE=1\r\n");
    WIFI_Send("AT+RST=1\r\n");
    delay_ms(3000);
    WIFI_Send("AT+CWJAP=\"R\",\"1234567890\"\r\n");
    delay_ms(10000);
    WIFI_Send("AT+CIPMUX=0\r\n");
    WIFI_Send("AT+CIPMODE=1\r\n");
    WIFI_Send("AT+ATKCLDSTA=\"16735421882671220579\",\"12345678\"\r\n");
     WIFI_Send("AT+SEND\r\n");
    //WIFI_Send("AT+CIPSTART=\"TCP\",\"10.22.27.71\",8080");
}





