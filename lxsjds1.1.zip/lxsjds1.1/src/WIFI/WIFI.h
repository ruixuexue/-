/*
 * WIFI.h
 *
 * created: 2024/6/28
 *  author: 
 */

#ifndef _WIFI_H
#define _WIFI_H

#include "ls1b.h"
#include "mips.h"
#include "ns16550.h"
#include <stdio.h>
#include <string.h>


typedef unsigned char u8;
typedef unsigned int u16;

void WIFI_Config(int time,char *cmd,char *response);
void WIFI_pro(void);
void UART3_Config_Init(void);
void UART4_Config_Init(void);

#endif // _WIFI_H
