/*
 * buzzer.h
 *
 * created: 2021/7/14
 *  author: 
 */

#ifndef _BUZZER_H
#define _BUZZER_H

void PCA9557_Test(void);
void Buzzer_ON(void);
void Buzzer_OFF(void);

#endif // _BUZZER_H

