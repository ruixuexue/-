/*
 * opt3002.h
 *
 * created: 2021/6/5
 *  author: 
 */

#ifndef _OPT3002_H
#define _OPT3002_H

void Get_OPT_ID(void);
void OPT3002_Conf(void);
float OPT3002_RD_Data(void);
void LED9_ON(void);
void LED9_OFF(void);

#endif // _OPT3002_H

