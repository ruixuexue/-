/*
 * tsl2561fn.h
 *
 * created: 2021/8/25
 *  author: 
 */

#ifndef _TSL2561FN_H
#define _TSL2561FN_H


void TSL_init(void);
float TSL2561FN_RD_Data(void);
void LED9_ON(void);
void LED9_OFF(void);

#endif // _TSL2561FN_H

