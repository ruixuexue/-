/*
 * other.h
 *
 * created: 2021/6/7
 *  author: 
 */

#ifndef _OTHER_H
#define _OTHER_H

void Other_init(void);
unsigned char IR_Read_Status(void);
unsigned char MQ_Read_Status(void);
unsigned char KTM_Read_Status(void);
void LED7_ON(void);
void LED7_OFF(void);

#endif // _OTHER_H

