/*
 * exti.h
 *
 * created: 2021/4/29
 *  author:
 */

#ifndef _KEY_H
#define _KEY_H

#include "ls1b_gpio.h"
#include "ls1b.h"

void KEY_IO_Config(void);
unsigned char KeyScan(void);

#endif // _EXTI_H


