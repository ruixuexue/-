/*
 * relay.h
 *
 * created: 2021/4/19
 *  author: 
 */

#ifndef _RELAY_H
#define _RELAY_H

#include "ns16550.h"

#define RELAY_ON    1
#define RELAY_OFF   0

#define RELAY_FLASH_OFF    0x04     //����ģʽ
#define RELAY_FLAHS_ON     0x02     //����ģʽ

#endif // _RELAY_H

